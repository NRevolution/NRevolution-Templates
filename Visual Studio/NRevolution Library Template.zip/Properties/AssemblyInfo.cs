﻿using System.Reflection;

[assembly: AssemblyTitle("$safeprojectname$")]